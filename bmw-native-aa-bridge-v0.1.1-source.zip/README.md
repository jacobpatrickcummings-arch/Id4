# BMW Native AA Bridge — research prototype (0.1.1)

**This is not an Android Auto runtime.** The aim is a non-flashing AAIdrive addon and BMW AM icon feasibility test on a factory ID4 unit. The Android Auto video/audio/projection functions have **not** been implemented. Please read [`docs/FEASIBILITY.md`](docs/FEASIBILITY.md) first.

## What the APK does

1. Advertises a service with action `io.bimmergestalt.carconnection.service`, which AAIdrive looks for when connecting the car.
2. Accepts AAIdrive's documented connection metadata, logs an addon-binding event, and shows logs in a phone UI, with a button to copy logs for troubleshooting.
3. Optionally, after the user opts in, attempts one **temporary** AM-icon registration via the existing BMW remoting tunnel. This uses My BMW's certificate and is **not proven sufficient** for authentication; failure is expected on systems requiring an additional app certificate. The icon is named `Android Auto (test)` to avoid confusing it with a working Android Auto runtime.
4. If the icon is registered and pressed, logs the event only. It does NOT start Android Auto.

There is no SSH, no coding, no custom APK signing certificate for BMW, no head-unit file manipulation, no overwrite of car settings, no need to disable AAIdrive.

## Build an Android APK (no Android Studio needed)

1. Create an empty private GitHub repo, e.g. `BMW-Native-AA-Bridge`, then upload the **contents** of this folder including `.github/workflows/build-apk.yml`.
2. Visit **Actions** → **Build AAIdrive bridge research APK**. Run manually or trigger by pushing to main.
3. When the workflow succeeds, open the run and download the `bmw-aa-bridge-research-debug-apk` artifact ZIP.
4. Unzip and install `app-debug.apk` on your Android 14 phone. Debug APK is locally signed by the GitHub Actions Android build tools; it is not a verified release build.

If this repository is private and ChatGPT cannot access it, open [GitHub App installations](https://github.com/settings/installations), select the GitHub connection used by ChatGPT, choose **Configure**, and grant access to the new repository. Reconnect the GitHub app in ChatGPT if it still cannot see the repository.

This prototype uses the same `io.bimmergestalt:IDriveConnectKitAndroid:0.6` dependency the BimmerGestalt ScreenMirror example declares. Its Maven/JitPack availability and full Gradle compilation must be verified by the workflow. **The APK has not been built in this environment because Android SDK/Gradle and external dependency downloads are unavailable.**

## Safe in-car validation

With the car parked, ensure My BMW + AAIdrive already work. Install this app, open it once and leave experimental registration disabled. Reconnect AAIdrive; check whether `BMW Native AA Bridge` appears in AAIdrive's Addons area, and check the phone diagnostics for `AAIdrive addon binding received`. **This only tests addon discovery**, not an iDrive menu entry.

If you explicitly choose to enable the experiment in the phone app, reconnect AAIdrive, inspect logs and look for `Android Auto (test)` in ConnectedDrive. A certificate failure or missing icon is not a failure of the discovery milestone. Turn the experiment OFF and reconnect to stop attempts.

## Status matrix

| Acceptance test | Status |
| --- | --- |
| Source code assembled | Complete |
| Unit tests/manifest/static validation | Static checks only; Gradle test awaits CI |
| APK compilation | Not run; requires GitHub Actions or Android SDK |
| Android 14 installation | Untested |
| AAIdrive addon discovery | Source-grounded, untested in vehicle |
| BMW AM registration | Experimental, untested; authentication may fail |
| iDrive icon press callback | Implemented experimentally, untested |
| Genuine Android Auto session | **Not implemented** |
| H.264/video, audio, rotary-controller AA control | **Not implemented** |
| Existing HU/ECUs unmodified | Design has no HU flashing/writes; real hardware not tested |

## Rollback

Disable experimental registration and reconnect AAIdrive; or simply uninstall the app on the phone. The project contains no head-unit installation process or firmware modifications. BMW may retain temporary UI entries during a session, disappearing when the connection ends.

## Licence

This repository's original implementation is provided under MIT (`LICENSE`). Third-party libraries remain under their own licences. No NBT-AAD or BMW copyrighted assets included. Not affiliated with BMW or Google.
