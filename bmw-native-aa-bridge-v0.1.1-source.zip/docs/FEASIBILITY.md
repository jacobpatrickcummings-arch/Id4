# NBT EVO ID4 — evidence-based feasibility (23 Nov 2026)

## Scope
2016 BMW 225d F22; unmodified NBT EVO ID4; Samsung Galaxy A13 5G; existing My BMW and AAIdrive. No HU software access was granted and no vehicle tests were performed.

## Verified from public source code / project author docs

* AAIdrive's `AddonDiscovery.kt` discovers services matching `io.bimmergestalt.carconnection.service`. `AddonsService.kt` binds them and passes `EXTRA_BRAND`, `EXTRA_HOST`, `EXTRA_PORT`, `EXTRA_INSTANCE_ID`. See BimmerGestalt/AAIdrive.
* AM icons can be registered over authenticated BMW remoting with `am_create`, `am_addAppEventHandler`, `am_registerApp` and `am_onAppEvent`. See `AMAppList.kt` and `IDriveConnectAddons/screen_mirror/.../CarApp.kt`. This does **not** provide a video projection channel.
* NBT-AAD targets NBT EVO ID6, requires Apple CarPlay, Wi-Fi antenna and SSH according to its README/requirements. Its install guide identifies AAIdrive coexistence as a known limitation.
* NBT-AAD's confirmed-working list includes a **2016 F22 M235i upgraded ID4 to ID6**, not an unmodified ID4.
* JayJay3071/nbt-android-auto explicitly targets original QNX/x86 NBT and explicitly excludes NBT EVO.
* deathwalker80/nbt-aa-tile uses a pre-existing CarLife HMI entry and head-unit-side code. It reports an ID5/ID6 system lacking the CarLife asset where the tile cannot appear.
* BimmerGestalt's CarAppAssetResources references an app-specific `*.p7b` certificate plus My BMW-issued certificate; the AAIdrive addon examples use a third-party application certificate extracted from a separately acquired APK. This research project does **not** bundle third-party certificates.

## Hypotheses / blockers

* AAIdrive discovery of this APK is plausible and source-grounded; in-car detection remains untested.
* A BMW icon may be achievable using an authenticated addon. This project's experimental mode probes whether the My BMW certificate by itself is accepted; **the probability of rejection is significant** because app-specific certificates are normally required. No head-unit files will be changed.
* A valid icon does **not** establish Android Auto runtime availability. No confirmed original ID4 port of NBT-AAD was found.
* NBT-AAD's documented AAIdrive conflict could prevent simultaneous use even on ID6 and demands upstream investigation before bridging launch behavior.
* The stock ConnectedDrive transport is not equivalent to an Android Auto high-bandwidth, low-latency video/audio interface. No evidence was found that BMW's AM protocol can create one.

## Architecture comparison

| Candidate | Status | Risk |
| --- | --- | --- |
| Pure AAIdrive launcher | Partially code-grounded, native Android Auto blocked | Low vehicle risk |
| AAIdrive + NBT-AAD on existing ID4 | ID4 runtime and coexistence unverified | Unproven and potentially intrusive |
| Minimal reversible ID4 HU-side runtime | No verified implementation available | Intrusive; no install permitted |
| ID4 -> ID6 retrofit + NBT-AAD | Documented for some F22 vehicles | Changes HU firmware/coding; explicitly out of scope |

## Follow-on experiments (consent before any HU modification)

1. Install only the research APK and verify AAIdrive Addons list discovery.
2. Opt into the *temporary* AM registration test while stationary; inspect diagnostics.
3. Independently document exact `NBTevo_*` version and whether CarPlay/Wi-Fi antenna already exists.
4. If certificate failure occurs, consider a source-level AAIdrive AM integration on an authorized connection, NOT importing proprietary certificates.
5. Only pursue an ID4 native runtime once a credible source-level port and reversible test strategy exist.

## Source links and licenses

- https://github.com/BimmerGestalt/AAIdrive (MIT)
- https://github.com/BimmerGestalt/IDriveConnectKitAndroid (MIT)
- https://github.com/BimmerGestalt/IDriveConnectAddons (MIT)
- https://github.com/Sq00ky/Supra-iDrive6-Android-Auto (PolyForm Noncommercial 1.0.0)
- https://github.com/JayJay3071/nbt-android-auto (PolyForm Noncommercial 1.0.0)
- https://github.com/deathwalker80/nbt-aa-tile (PolyForm Noncommercial 1.0.0)

No NBT-AAD or OEM proprietary software is included in this repo.
