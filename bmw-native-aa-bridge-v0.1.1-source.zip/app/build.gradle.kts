plugins {
    id("com.android.application")
    kotlin("android")
}
android {
    namespace = "uk.roadguard.nbtbridge"
    compileSdk = 35
    defaultConfig {
        applicationId = "uk.roadguard.nbtbridge"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.1-spike"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    // Existing, documented dependency used by BimmerGestalt's ScreenMirror addon.
    implementation("io.bimmergestalt:IDriveConnectKitAndroid:0.6")
    testImplementation("junit:junit:4.13.2")
}
