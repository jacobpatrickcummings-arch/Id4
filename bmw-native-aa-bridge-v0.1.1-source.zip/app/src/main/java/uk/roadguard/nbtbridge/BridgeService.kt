package uk.roadguard.nbtbridge

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.util.Log
import de.bmw.idrive.BMWRemoting
import de.bmw.idrive.BMWRemotingServer
import de.bmw.idrive.BaseBMWRemotingClient
import io.bimmergestalt.idriveconnectkit.IDriveConnection
import io.bimmergestalt.idriveconnectkit.android.IDriveConnectionReceiver
import io.bimmergestalt.idriveconnectkit.android.security.SecurityAccess
import java.io.ByteArrayOutputStream
import java.util.concurrent.atomic.AtomicBoolean
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint

/**
 * Non-persistent AAIdrive connection addon.
 * The AM registration path is exploratory: a proper app-specific certificate has
 * NOT been provided. We do not ship BMW assets, perform SSH, or edit the head unit.
 */
class BridgeService : Service() {
    companion object {
        private const val IDENT = "uk.roadguard.nbtbridge.launcher"
        private const val INTENT_ACTION = "io.bimmergestalt.carconnection.service"
    }
    private val stopping = AtomicBoolean(false)
    private var worker: Thread? = null
    @Volatile private var conn: BMWRemotingServer? = null
    @Volatile private var amHandle: Int? = null
    private val sessionGuard = Any()

    override fun onCreate() {
        super.onCreate()
        StatusStore.log(this, "BridgeService created; looking for My BMW security service")
        try { SecurityAccess.getInstance(applicationContext).connect() }
        catch (e: Exception) { StatusStore.log(this, "Security service unavailable: ${e.javaClass.simpleName}") }
    }

    override fun onBind(intent: Intent?): IBinder? {
        if (intent == null || intent.action != INTENT_ACTION) {
            StatusStore.log(this, "Ignoring unexpected binding")
            return null
        }
        try {
            IDriveConnectionReceiver().onReceive(applicationContext, intent)
        } catch (e: Exception) {
            StatusStore.log(this, "Connection metadata rejected: ${e.javaClass.simpleName}")
            return null
        }
        // Do not log VIN, raw credentials or head-unit IP addresses.
        StatusStore.log(this, "AAIdrive addon binding received")
        if (StatusStore.enabled(this) && worker?.isAlive != true && conn == null) {
            stopping.set(false)
            worker = Thread({ tryRegisterIcon() }, "am-probe").also { it.start() }
        } else if (!StatusStore.enabled(this)) {
            StatusStore.log(this, "Safe discovery-only mode; no BMW AM connection attempted")
        }
        // AAIdrive accepts a null binding (see its AddonsService implementation).
        return null
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == INTENT_ACTION) onBind(intent)
        return START_NOT_STICKY
    }

    private fun tryRegisterIcon() {
        val status = IDriveConnectionReceiver()
        val host = status.host
        val port = status.port
        val brand = status.brand ?: "bmw"
        if (host == null || !(host == "localhost" || host.startsWith("127.")) || port == null || port !in 1..65535) {
            StatusStore.log(this, "Registration blocked: unexpected connection endpoint")
            return
        }
        val security = SecurityAccess.getInstance(applicationContext)
        for (i in 0..5) {
            if (stopping.get()) return
            if (security.isConnected()) break
            try {
                Thread.sleep(750)
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
                StatusStore.log(this, "Icon registration cancelled safely")
                return
            }
        }
        if (!security.isConnected() || stopping.get()) {
            StatusStore.log(this, "Registration stopped: security service not ready")
            return
        }
        try {
            val listener = object : BaseBMWRemotingClient() {
                override fun am_onAppEvent(handle: Int?, ident: String?, appId: String?, event: BMWRemoting.AMEvent?) {
                    if (appId == IDENT) {
                        StatusStore.log(applicationContext, "BMW icon pressed. No native Android Auto runtime installed; no action taken.")
                    }
                }
            }
            val session = IDriveConnection.getEtchConnection(host, port, listener)
            synchronized(sessionGuard) {
                if (stopping.get()) {
                    try { IDriveConnection.disconnectEtchConnection(session) } catch (_: Exception) {}
                    return
                }
                conn = session
            }
            // Research-only hypothesis: some cars may accept My BMW's certificate alone.
            // If rejected, do not retry/modify the HU or import proprietary app certs.
            val officialCert = security.fetchBMWCerts(brandHint = brand)
            val challenge = session.sas_certificate(officialCert)
            session.sas_login(security.signChallenge(challenge = challenge))
            if (stopping.get()) return
            val handle = session.am_create("0", byteArrayOf(0, 0, 0, 0, 0, 2, 0, 0))
            amHandle = handle
            session.am_addAppEventHandler(handle, IDENT)
            val info = mutableMapOf<Int, Any>(
                0 to 145,
                1 to "Android Auto (test)",
                2 to makeIcon(),
                3 to "OnlineServices",
                4 to true,
                5 to 850,
                8 to -1
            )
            for (language in 101..123) info[language] = "Android Auto (test)"
            session.am_registerApp(handle, IDENT, info)
            StatusStore.log(this, "BMW AM registration call returned; check if the icon actually appears")
            // Connection must stay open while the icon is registered.
        } catch (e: Exception) {
            Log.w("BmwNativeAaBridge", "AM probe failed", e)
            StatusStore.log(this, "BMW AM registration failed: ${e.javaClass.simpleName}. No files modified.")
            closeSession()
        }
    }

    private fun makeIcon(): ByteArray {
        val bitmap = Bitmap.createBitmap(48, 48, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.BLACK)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; textAlign = Paint.Align.CENTER; textSize = 20f; isFakeBoldText = true
        }
        canvas.drawText("AA", 24f, 30f, paint)
        val output = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)
        bitmap.recycle()
        return output.toByteArray()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        stopProbe()
        StatusStore.log(this, "AAIdrive disconnected; bridge stopped")
        return false
    }
    private fun stopProbe() {
        stopping.set(true)
        worker?.interrupt()
        closeSession()
    }

    /** Always release the temporary AM handle before dropping the BMW connection. */
    private fun closeSession() {
        synchronized(sessionGuard) {
            val session = conn ?: return
            try {
                amHandle?.let { session.am_dispose(it) }
            } catch (e: Exception) {
                Log.d("BmwNativeAaBridge", "AM cleanup: ${e.javaClass.simpleName}")
            }
            try {
                IDriveConnection.disconnectEtchConnection(session)
            } catch (e: Exception) {
                Log.d("BmwNativeAaBridge", "Connection cleanup: ${e.javaClass.simpleName}")
            }
            conn = null
            amHandle = null
        }
    }
    override fun onDestroy() { stopProbe(); super.onDestroy() }
}
