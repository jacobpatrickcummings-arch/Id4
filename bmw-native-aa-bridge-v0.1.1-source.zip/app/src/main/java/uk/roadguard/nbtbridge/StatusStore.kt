package uk.roadguard.nbtbridge

import android.content.Context
import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

internal object StatusStore {
    private const val PREFS = "roadguard_bridge"
    private const val KEY_LOG = "log"
    private const val KEY_OPT_IN = "am_opt_in"
    private const val MAX_CHARS = 12000
    fun enabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_OPT_IN, false)
    fun setEnabled(context: Context, value: Boolean) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_OPT_IN, value).apply()
    fun log(context: Context, msg: String) {
        Log.i("BmwNativeAaBridge", msg)
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val clock = SimpleDateFormat("HH:mm:ss", Locale.UK).format(Date())
        val old = prefs.getString(KEY_LOG, "") ?: ""
        val combined = "$clock $msg\n$old"
        prefs.edit().putString(KEY_LOG, combined.take(MAX_CHARS)).apply()
    }
    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().remove(KEY_LOG).apply()
    }
    fun read(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_LOG, "No events received yet. Connect to AAIdrive.") ?: ""
}

