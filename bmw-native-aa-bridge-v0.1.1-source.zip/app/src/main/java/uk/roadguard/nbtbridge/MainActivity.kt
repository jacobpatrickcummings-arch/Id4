package uk.roadguard.nbtbridge

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

/** Phone-side diagnostic UI. No Android Auto projection is implemented here. */
class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var logs: TextView
    private val refresher = object : Runnable {
        override fun run() {
            if (::logs.isInitialized) logs.text = StatusStore.read(this@MainActivity)
            handler.postDelayed(this, 1500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val outer = ScrollView(this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
            gravity = Gravity.START
        }
        fun text(s: String, size: Float = 16f): TextView = TextView(this).apply {
            text = s; textSize = size; setPadding(0, 8, 0, 12)
            layout.addView(this)
        }
        text("BMW Native AA Bridge", 24f)
        text("Stage B research build — NOT genuine Android Auto. It only tests AAIdrive discovery and optional BMW launcher registration.")
        val optIn = Switch(this).apply {
            text = "Try experimental ConnectedDrive icon registration (no head-unit files changed)"
            isChecked = StatusStore.enabled(this@MainActivity)
            setOnCheckedChangeListener { _, checked ->
                StatusStore.setEnabled(this@MainActivity, checked)
                StatusStore.log(this@MainActivity, "Experimental icon registration set to $checked. Reconnect AAIdrive to apply.")
            }
        }
        layout.addView(optIn)
        text("Default OFF. Registration requires an authenticated BMW session; My BMW's security certificate alone may be rejected. If an icon appears, selecting it will ONLY log the event; no native runtime exists.", 14f)
        text("Diagnostics", 20f)
        logs = text("", 12f)
        layout.addView(Button(this).apply {
            text = "Refresh logs"
            setOnClickListener { logs.text = StatusStore.read(this@MainActivity) }
        })
        layout.addView(Button(this).apply {
            text = "Copy diagnostics"
            setOnClickListener {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("BMW Native AA Bridge diagnostics", StatusStore.read(this@MainActivity)))
                StatusStore.log(this@MainActivity, "Diagnostics copied to clipboard")
            }
        })
        layout.addView(Button(this).apply {
            text = "Clear diagnostics"
            setOnClickListener {
                StatusStore.clear(this@MainActivity)
                logs.text = StatusStore.read(this@MainActivity)
            }
        })
        outer.addView(layout)
        setContentView(outer)
    }
    override fun onResume() { super.onResume(); handler.post(refresher) }
    override fun onPause() { handler.removeCallbacks(refresher); super.onPause() }
}
