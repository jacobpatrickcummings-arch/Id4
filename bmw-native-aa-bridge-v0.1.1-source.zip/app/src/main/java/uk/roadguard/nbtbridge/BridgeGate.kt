package uk.roadguard.nbtbridge

/** Pure, testable safety policy: never advertise native projection as enabled without evidence. */
internal object BridgeGate {
    fun projectionAllowed(id4RuntimeVerified: Boolean, nativeRuntimeReady: Boolean): Boolean =
        id4RuntimeVerified && nativeRuntimeReady
}
