package uk.roadguard.nbtbridge

import org.junit.Assert.*
import org.junit.Test

class BridgeGateTest {
    @Test fun blocksUnverifiedID4() {
        assertFalse(BridgeGate.projectionAllowed(false, true))
    }
    @Test fun blocksMissingNativeRuntime() {
        assertFalse(BridgeGate.projectionAllowed(true, false))
    }
    @Test fun onlyPermitsVerifiedCombination() {
        assertTrue(BridgeGate.projectionAllowed(true, true))
    }
}
