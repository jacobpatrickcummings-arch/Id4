"""Static contract checks runnable without Android SDK or proprietary dependencies."""
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ANDROID_NS = "{http://schemas.android.com/apk/res/android}"

class ContractTests(unittest.TestCase):
    def setUp(self):
        self.manifest = ET.parse(ROOT / 'app/src/main/AndroidManifest.xml').getroot()
        self.service = (ROOT / 'app/src/main/java/uk/roadguard/nbtbridge/BridgeService.kt').read_text()

    def test_addon_service_discovery_action(self):
        services = self.manifest.findall('.//service')
        self.assertEqual(len(services), 1)
        self.assertEqual(services[0].attrib[ANDROID_NS + 'exported'], 'true')
        actions = {a.attrib[ANDROID_NS + 'name'] for a in services[0].findall('.//action')}
        self.assertIn('io.bimmergestalt.carconnection.service', actions)

    def test_registration_not_enabled_by_default(self):
        store = (ROOT / 'app/src/main/java/uk/roadguard/nbtbridge/StatusStore.kt').read_text()
        self.assertIn('getBoolean(KEY_OPT_IN, false)', store)

    def test_registration_stays_nonpersistent(self):
        prohibited = ('mount -o remount', 'ProcessBuilder(', 'Runtime.getRuntime(', 'ssh root@', 'su -c')
        for pattern in prohibited:
            self.assertNotIn(pattern, self.service)

    def test_interrupt_is_handled_in_worker(self):
        self.assertIn('catch (_: InterruptedException)', self.service)
        self.assertIn('Thread.currentThread().interrupt()', self.service)

    def test_session_cleanup(self):
        self.assertIn('session.am_dispose(it)', self.service)
        self.assertIn('IDriveConnection.disconnectEtchConnection(session)', self.service)

    def test_diagnostics_export(self):
        ui = (ROOT / 'app/src/main/java/uk/roadguard/nbtbridge/MainActivity.kt').read_text()
        self.assertIn('Copy diagnostics', ui)
        self.assertIn('ClipboardManager', ui)

    def test_build_workflow(self):
        wf = (ROOT / '.github/workflows/build-apk.yml').read_text()
        self.assertIn(':app:testDebugUnitTest :app:assembleDebug', wf)
        self.assertIn('upload-artifact@v4', wf)

    def test_native_projection_not_misrepresented(self):
        readme = (ROOT / 'README.md').read_text().lower()
        self.assertIn('not an android auto runtime', readme)
        self.assertIn('not implemented', readme)

if __name__ == '__main__':
    unittest.main()
